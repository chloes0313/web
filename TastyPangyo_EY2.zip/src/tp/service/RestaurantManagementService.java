package tp.service;
/**
 * 관리자의 맛집관리 서비스
 * @author Chloe
 *
 */
public interface RestaurantManagementService {
	
	void selectRestaurantByID(int restaurantId);

}
