package tp.service;

/**
 * 관리자의 회원관리 서비스
 * @author Chloe
 *
 */
public interface MemberManagementService {


	
}
